﻿namespace Motosalon.Models
{
    /// <summary>
    /// https://en.wikipedia.org/wiki/Cruiser_(motorcycle)
    /// </summary>
    public class Cruisers : MotorcycleBaseClass
    {
        public override int Power => 1500;
    }
}
