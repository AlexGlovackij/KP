﻿namespace Motosalon.Models
{
    /// <summary>
    /// https://en.wikipedia.org/wiki/Moped
    /// </summary>
    public class Moped : MotorcycleBaseClass
    {
        public override int Power => 100;
    }
}
