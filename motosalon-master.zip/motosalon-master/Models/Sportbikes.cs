﻿namespace Motosalon.Models
{
    /// <summary>
    /// https://en.wikipedia.org/wiki/Sport_bike
    /// </summary>
    public class Sportbikes : MotorcycleBaseClass
    {
        public override int Power => 1000;
    }
}
